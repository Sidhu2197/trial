package com.EducationVision.EducationVision;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EducationVisionApplicationTests {

	@Test
	void contextLoads() {
	}

}
