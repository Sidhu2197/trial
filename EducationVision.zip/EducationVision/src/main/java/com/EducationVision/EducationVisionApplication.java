package com.EducationVision;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EducationVisionApplication {

	public static void main(String[] args) {
		SpringApplication.run(EducationVisionApplication.class, args);
	}

}
